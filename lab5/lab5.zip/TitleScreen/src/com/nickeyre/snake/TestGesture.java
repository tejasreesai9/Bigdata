 package com.nickeyre.snake; 
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.List;

import android.os.Environment;
import android.util.Log;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationVector;
import be.ac.ulg.montefiore.run.jahmm.OpdfMultiGaussianFactory;
import be.ac.ulg.montefiore.run.jahmm.io.ObservationSequencesReader;
import be.ac.ulg.montefiore.run.jahmm.io.ObservationVectorReader;
import be.ac.ulg.montefiore.run.jahmm.learn.BaumWelchLearner;
import be.ac.ulg.montefiore.run.jahmm.learn.KMeansLearner;

  
public class TestGesture {
	OpdfMultiGaussianFactory initFactoryleft=null;
	Reader learnReaderleft=null;
	List<List<ObservationVector>> learnSequencesleft=null;
	KMeansLearner<ObservationVector> kMeansLearnerleft=null;
	Hmm<ObservationVector> initHmmPunch=null;
	Hmm<ObservationVector> learntHmmright=null;
	Hmm<ObservationVector> learntHmmleft=null;
	Hmm<ObservationVector> learntHmmup=null;
	Hmm<ObservationVector> learntHmmdown=null;
	 String root = Environment.getExternalStorageDirectory().toString();
	    File myDir = new File(root + "/Data");    
	   
public void	train() {
	 myDir.mkdirs();
	// Create HMM for punch gesture
	Boolean exception =false;
	int x=5;
	//while(!exception){
	try{
    OpdfMultiGaussianFactory initFactoryleft = new OpdfMultiGaussianFactory(
            3);
    
    Reader learnReaderleft = new FileReader(new File (myDir, "left.seq"));
    List<List<ObservationVector>> learnSequencesleft = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(), learnReaderleft);
    learnReaderleft.close();

    KMeansLearner<ObservationVector> kMeansLearnerleft = new KMeansLearner<ObservationVector>(
            x, initFactoryleft, learnSequencesleft);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmleft = kMeansLearnerleft.iterate();
    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    
    BaumWelchLearner baumWelchLearnerleft = new BaumWelchLearner();
     this.learntHmmleft = baumWelchLearnerleft.learn(
            initHmmleft, learnSequencesleft);
    exception=true;
    System.out.println(x);
	  }
	  catch(Exception e){
		  e.printStackTrace();
		  x--;
		  //System.out.println(x);
		  
	  }

//}
	// Create HMM for down gesture
		Boolean exception4 =false;
		int x4=5;
		//while(!exception){
		try{
	    OpdfMultiGaussianFactory initFactorydown = new OpdfMultiGaussianFactory(
	            3);
	    
	    Reader learnReaderdown = new FileReader(new File (myDir, "down.seq"));
	    List<List<ObservationVector>> learnSequencesdown= ObservationSequencesReader
	            .readSequences(new ObservationVectorReader(), learnReaderdown);
	    learnReaderdown.close();

	    KMeansLearner<ObservationVector> kMeansLearnerdown = new KMeansLearner<ObservationVector>(
	            x4, initFactorydown, learnSequencesdown);
	    // Create an estimation of the HMM (initHmm) using one iteration of the
	    // k-Means algorithm
	    Hmm<ObservationVector> initHmmdown = kMeansLearnerdown.iterate();
	    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
	    
	    BaumWelchLearner baumWelchLearnerdown = new BaumWelchLearner();
	     this.learntHmmdown = baumWelchLearnerdown.learn(
	            initHmmdown, learnSequencesdown);
	    exception=true;
	    System.out.println(x);
		  }
		  catch(Exception e){
			  e.printStackTrace();
			  x4--;
			  //System.out.println(x);
			  
		  }

	//}
    // Create HMM for scroll-down gesture
	Boolean exception1 =false;
	int x1=5;
	//while(!exception1){
	try{
    OpdfMultiGaussianFactory initFactoryright = new OpdfMultiGaussianFactory(
            3);

    Reader learnReaderright = new FileReader(new File (myDir, "right.seq"));
    List<List<ObservationVector>> learnSequencesright = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(),
                    learnReaderright);
    learnReaderright.close();

    KMeansLearner<ObservationVector> kMeansLearnerright = new KMeansLearner<ObservationVector>(
            x1, initFactoryright, learnSequencesright);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmright = kMeansLearnerright.iterate();

    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    BaumWelchLearner baumWelchLearnerright = new BaumWelchLearner();
     this.learntHmmright = baumWelchLearnerright
            .learn(initHmmright, learnSequencesright);
     exception1=true;
     //System.out.println("here1");
     System.out.println(x1);
	  }
	  catch(Exception e){
		  e.printStackTrace();
		  x1--;
		  //System.out.println(x1);
		  
	  }
//	}
    // Create HMM for send gesture
	Boolean exception2 =false;
	int x2=5;
	//while(!exception2){
	try{
    OpdfMultiGaussianFactory initFactoryup = new OpdfMultiGaussianFactory(
            3);

    Reader learnReaderup = new FileReader(new File (myDir, "up.seq"));
    List<List<ObservationVector>> learnSequencesup = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(), learnReaderup);
    learnReaderup.close();

    KMeansLearner<ObservationVector> kMeansLearnerup = new KMeansLearner<ObservationVector>(
            x2, initFactoryup, learnSequencesup);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmup = kMeansLearnerup.iterate();

    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    BaumWelchLearner baumWelchLearnerup = new BaumWelchLearner();
     this.learntHmmup = baumWelchLearnerup.learn(
            initHmmup, learnSequencesup);
     exception2=true;
     System.out.println(x2);
	  }
	  catch(Exception e){
		  e.printStackTrace();
		  x2--;
		  //System.out.println(x2);
		  
	  }
	}
	//}
	
    public String test(File seqfilename) throws Exception{
        Reader testReader = new FileReader(seqfilename);
        List<List<ObservationVector>> testSequences = ObservationSequencesReader
                .readSequences(new ObservationVectorReader(), testReader);
        testReader.close();
        
        short gesture; // punch = 1, scrolldown = 2, send = 3
        double leftProbability, downProbability, rightProbability, upProbability;
        for (int i = 0; i < testSequences.size(); i++) {
       
            leftProbability = this.learntHmmleft.probability(testSequences
                    .get(i));
            //System.out.println(this.learntHmmPunch.probability(testSequences.get(i)));
            gesture = 1;
            //System.out.println(this.learntHmmScrolldown);
            downProbability = this.learntHmmdown.probability(testSequences
                    .get(i));
            
            if (downProbability > leftProbability) {
                gesture = 2;
            }
            rightProbability = this.learntHmmright.probability(testSequences
                    .get(i));
            
            upProbability = this.learntHmmup.probability(testSequences
            		.get(i));
            //System.out.println(punchProbability +","+scrolldownProbability +","+sendProbability);
            if ((gesture == 1 && rightProbability > leftProbability)
                    || (gesture == 2 && rightProbability > downProbability)) {
                gesture = 3;
            }
            if ((gesture == 1 && upProbability > leftProbability)
                    || (gesture == 2 && upProbability > downProbability)
                    || (gesture == 3 && upProbability > rightProbability)) {
                gesture = 4;
            }
            Log.i("probabilities", leftProbability + "   " + rightProbability  + "   " + downProbability + "  " + + upProbability  + "   ");
            
            if (gesture == 1) {
            	System.out.println("This is a left gesture");
            	return "left";
            } else if (gesture == 2) {
                System.out.println("This is a down gesture");
            	return "down";
            } else if (gesture == 3) {
            	System.out.println("This is a right gesture");
            	return "right";
            }else if (gesture == 4) {
            	System.out.println("This is a up gesture");
            	return "up";
            }else{
            	return "others";
            }
        }
		return "others";
    }
  
} 