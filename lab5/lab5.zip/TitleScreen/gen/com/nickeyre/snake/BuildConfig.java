/** Automatically generated file. DO NOT MODIFY */
package com.nickeyre.snake;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}